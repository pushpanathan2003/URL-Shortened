
from __future__ import unicode_literals

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
from django.contrib.auth.hashers import make_password
import surl.models


def create_sys_user(apps, schema_editor):
    user_model = apps.get_registered_model('auth', 'User')
    sys_user = user_model(
        username='surl_system',
        email='system@example.com',
        password=make_password('123'),
    )
    sys_user.is_active = False
    sys_user.save()
    profile_model = apps.get_registered_model('surl', 'Profile')
    profile_model(user=sys_user).save()


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Profile',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('count', models.IntegerField(default=0)),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Surl',
            fields=[
                ('slug', models.CharField(default=surl.models.gen_uuid, max_length=5, primary_key=True, serialize=False, unique=True)),
                ('url', models.URLField()),
                ('count', models.IntegerField(default=0)),
                ('password', models.CharField(blank=True, default='', max_length=20)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='urls', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.RunPython(create_sys_user),
    ]
