from django.apps import AppConfig


class SurlConfig(AppConfig):
    name = 'surl'
